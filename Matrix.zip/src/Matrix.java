public class Matrix {
    public static void main(String[] args) throws java.io.IOException {
        java.io.File file = new java.io.File("array.txt");
        if (file.exists()) {
            System.out.println("File already exists");
            System.exit(1);
        }
        {

            java.io.PrintWriter output = new java.io.PrintWriter(file);

            int[][][] arr = {
                    {{93, 15, 47},
                            { 11, 18, 5},
                            {14,81,19}},
                    {{ 7, 13, 17},
                            {9, 13, 81},
                            {21, 27, 75}},
                    {{ 2, 8, 18},
                            {29, 16, 21},
                            {51, 44, 76}}
            };



            for (int[][] item:arr){
                for (int[] item1:item){
                    for (int item2:item1){
                        output.print(" " + item2);
                    }
                }
            }

            output.close();
        }
    }}