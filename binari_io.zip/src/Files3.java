import java.io.*;

public class Files3 {
    public static void main(String[] args) {
        try {
            try (dOut output =
                         new dOut(new fOut("temp3.data"))) {
                output.writeDouble(3.5);
                output.writeDouble(6.5);
                output.writeDouble(1.5);
            }

            try (dInp input =
                         new dInp(new fInp("temp3.data"))) {
                while (true)
                    System.out.println(input.readDouble());
            }
        }
        catch (EOFException ex) {
            System.out.println("Data were read");
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}