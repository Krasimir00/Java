import java.io.*;

public class Files2 {
    public static void main(String[] args) throws IOException {
        try ( // Create an output stream for file temp.dat
              dOut output =
                      new dOut(new fOut("temp2.data"));
        ) {
            // Write student test scores to the file
            output.writeUTF("Ivan");
            output.writeDouble(76.5);
            output.writeUTF("Dimityr");
            output.writeDouble(134.3);
            output.writeUTF("Petyr");
            output.writeDouble(96.5);
        }

        try ( // Create an input stream for file temp.dat
              dInp input =
                      new dInp(new dInp("temp2.data"));
        ) {
            // Read student test scores from the file
            System.out.println(input.readUTF() + " " + input.readDouble());
            System.out.println(input.readUTF() + " " + input.readDouble());
            System.out.println(input.readUTF() + " " + input.readDouble());
        }
    }
}