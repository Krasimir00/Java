public class Files1 {
    public static void main(String[] args) throws IOException {
        try (
                // Create an output stream to the file
                fOut output = new fOut("temp1.data");
        ) {
            // Output values to the file
            for (int i = 1; i <= 10; i++)
                output.write(i);
        }

        try (
                // Create an input stream for the file
                fInp input = new fInp("temp1.data");
        ) {
            // Read values from the file
            int value;
            while ((value = input.read()) != -1)
                System.out.print(value + " ");
        }
    }
}
